document.getElementById("orderForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Buyurtma qabul qilindi! Tez orada siz bilan bogʻlanamiz.");
  this.reset();
});
